package org.spring.projectjs.jdbc;

import lombok.Data;


/*
board_idx number primary key,
board_title varchar2(40),
board_content varchar2(2000),
board_visitcount number,
board_date date default sysdate ,
board_id number,
board_good number,
board_worse number,
ofile1 varchar2(100),
sfile1 varchar2(100),
ofile2 varchar2(100),
sfile2 varchar2(100),
ofile3 varchar2(100),
sfile3 varchar2(100)
*/


@Data
public class BoardDTO {
	
	//DAO에 사용할 번호
	private int num;
	
	private String board_idx;
	private String board_title;
	private String board_content;		
	private int board_visitcount;
	private java.sql.Date board_date;
	private int board_id;
	private int board_good;
	private int board_worse;	
	private String ofile1;
	private String sfile1;
	private String ofile2;
	private String sfile2;
	private String ofile3;
	private String sfile3;
	private int member_idx_board;
	public BoardDTO() {
	    // 기본 생성자 명시적으로 추가
	}

	// 추가된 생성자
	public BoardDTO(String board_idx) {
	    this.board_idx = board_idx;
	}
	
}
