document.addEventListener('DOMContentLoaded', () => {
    var Calendar = window.tui.Calendar;

    const COLOR_MAP = {
        pink:   '#ffd1e8',
        blue:   '#cfe9ff',
        green:  '#d8f5d0',
        yellow: '#fff6bf'
    };

    const cal = new Calendar('#calendar', {
        defaultView: 'month',
        useFormPopup: false,
        useDetailPopup: false,
        isReadOnly: false,
        month: { showEventTime: false },
        calendars: [{ id: 'plant', name: 'Plant', backgroundColor: '#e9f2ff' }],
    });

    // 날짜 변경 시 서버에 업데이트 요청 추가
    cal.on('beforeUpdateSchedule', async ({ schedule, changes }) => {
        if (!changes.start) return;  // 시작일 변경 없으면 무시
        cal.updateSchedule(schedule.id, schedule.calendarId, changes); // 화면 업데이트

        const newStart = changes.start instanceof Date
            ? toLocalYMD(changes.start)
            : (typeof changes.start === 'string' ? changes.start : toLocalYMD(new Date(changes.start)));

        const csrf = getCsrf();
        const headers = { 'Content-Type': 'application/json' };
        if (csrf) headers[csrf.header] = csrf.token;

        try {
            const res = await fetch(`${window.APP_CTX || ''}/calendar/updateDate.do`, {
                method: 'POST',
                headers,
                credentials: 'include',
                body: JSON.stringify({ id: schedule.id, start_date: newStart })
            });
            const data = await res.json();
            if (!res.ok || !data.ok) throw new Error('DB update failed');
        } catch (e) {
            alert('일정 날짜 업데이트 중 오류가 발생했습니다.');
            console.error(e);
            loadEvents();  // 실패 시 재조회로 원복
        }
    });

    function renderCurrentMonth() {
        const d = cal.getDate();
        const ym = `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}`;
        document.getElementById('currentMonth').textContent = ym;
    }
    const seenTitles = new Set();
    function resetSeen(){ seenTitles.clear(); }
    document.getElementById('btnToday').onclick  = () => { cal.today(); renderCurrentMonth(); resetSeen(); loadEvents(); };
    document.getElementById('btnPrev').onclick   = () => { cal.prev();  renderCurrentMonth(); resetSeen(); loadEvents(); };
    document.getElementById('btnNext').onclick   = () => { cal.next();  renderCurrentMonth(); resetSeen(); loadEvents(); };
    renderCurrentMonth();

    function toLocalYMD(date) {
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }
    function addDaysLocal(ymd, days) {
        const [y, m, d] = ymd.split('-').map(Number);
        const dt = new Date(y, m - 1, d);
        dt.setDate(dt.getDate() + days);
        return dt;
    }
    function getMonthRange() {
        const d = cal.getDate();
        const y = d.getFullYear(), m = d.getMonth();
        const first = new Date(y, m, 1);
        const nextFirst = new Date(y, m + 1, 1); // exclusive
        return { start: toLocalYMD(first), end: toLocalYMD(nextFirst) };
    }
    function resetSearch() {
        const kw = document.getElementById('plantKeyword');
        const sr = document.getElementById('searchResult');
        if (kw) kw.value = '';
        if (sr) sr.innerHTML = '';
    }
    function positionModalUnderCell(modal, nativeEvent) {
        let left = 100, top = 100;
        if (nativeEvent && nativeEvent.target) {
            const cell = nativeEvent.target.closest('.toastui-calendar-daygrid-cell, .toastui-calendar-weekday-grid-cell');
            if (cell) {
                const rect = cell.getBoundingClientRect();
                left = rect.left + window.scrollX;
                top = rect.bottom + window.scrollY + 8;
            }
        }
        modal.style.left = left + 'px';
        modal.style.top = top + 'px';
    }
    function getCsrf() {
        const token = document.querySelector('meta[name="_csrf"]')?.getAttribute('content');
        const header = document.querySelector('meta[name="_csrf_header"]')?.getAttribute('content');
        return token && header ? { header, token } : null;
    }

    // DB 이벤트 로드: 캘린더에는 '제목 (시작일)'로 표시, 원본은 raw에 보관
    async function loadEvents() {
        const { start, end } = getMonthRange();
        const url = `${window.APP_CTX||''}/calendar/list.do?start=${start}&end=${end}`;
        try {
            const res = await fetch(url, { headers: { 'Accept': 'application/json' }, credentials: 'include' });
            if (!res.ok) { cal.clear(); return; }
            const list = await res.json();

            cal.clear();
            const events = (Array.isArray(list) ? list : []).map(e => {
                const hex = COLOR_MAP[e.color] || '#eaeaea';
                const startYmd = e.start; // YYYY-MM-DD 가정
                return {
                    id: String(e.id),
                    calendarId: 'plant',
                    title: `${e.title} (${startYmd})`, // 화면용
                    start: e.start,
                    end:   e.end,
                    isAllday: true,
                    category: 'allday',
                    backgroundColor: hex,
                    borderColor: hex,
                    raw: { dbTitle: e.title, memo: e.memo || '', start: e.start } // 모달용 원본
                };
            });
            cal.createEvents(events);
            resetSeen();
        } catch (err) {
            console.error('loadEvents error', err);
        }
    }
    loadEvents();

    // 날짜 선택 → 검색 모달
    let lastNativeEvent = null;
    cal.on('selectDateTime', ({ start, nativeEvent }) => {
        lastNativeEvent = nativeEvent;
        const iso = toLocalYMD(start);
        showSearchModal(iso, nativeEvent);
        cal.clearGridSelections();
    });

    function showSearchModal(date, nativeEvent) {
        const modal = document.getElementById('plantSearchModal');
        document.getElementById('selectedDateText').textContent = '선택한 날짜: ' + date;
        resetSearch();
        positionModalUnderCell(modal, nativeEvent);
        modal.dataset.date = date;
        modal.style.display = 'block';
        document.getElementById('plantKeyword').focus();
    }

    function closeModal() {
        document.getElementById('plantSearchModal').style.display = 'none';
        resetSearch();
    }
    window.closeModal = closeModal;

    // 검색
    async function searchPlants() {
        const keywordEl = document.getElementById('plantKeyword');
        const container = document.getElementById('searchResult');
        const keyword = (keywordEl?.value || '').trim();

        container.innerHTML = '';
        if (!keyword) { container.innerHTML = '<div class="empty">검색어를 입력하세요.</div>'; return; }

        const url = `${window.APP_CTX || ''}/search.do?keyword=${encodeURIComponent(keyword)}`;
        try {
            const res = await fetch(url, { method: 'GET', headers: { 'Accept': 'application/json' }, credentials: 'include' });
            if (!res.ok) throw new Error('검색 실패');

            const ct = (res.headers.get('content-type') || '').toLowerCase();
            if (!ct.includes('application/json')) throw new Error('JSON 아님');

            const list = await res.json();
            if (!Array.isArray(list) || list.length === 0) {
                container.innerHTML = '<div class="empty">검색한 결과가 없습니다.</div>';
                return;
            }

            list.forEach(p => {
                if (!p) return;
                const n = p.name ?? '';
                const g = Number(p.max_grow_days ?? 0);
                if (!n) return;

                const div = document.createElement('div');
                div.className = 'result-item';
                div.textContent = g > 0 ? `${n} (${g}일)` : `${n}`;
                div.onclick = () => selectPlant({ name: n, growthPeriod: g });
                container.appendChild(div);
            });
        } catch (e) {
            container.innerHTML = '<div class="empty">오류가 발생했습니다.</div>';
            console.error(e);
        }
    }
    document.getElementById('plantSearchForm')?.addEventListener('submit', (e) => {
        e.preventDefault();
        searchPlants();
    });

    // 결과 클릭 → 등록 모달
    function selectPlant(plant) {
        const startYmd = document.getElementById('plantSearchModal').dataset.date;
        closeModal();

        const dm = document.getElementById('detailModal');
        document.getElementById('dDate').value   = startYmd;
        document.getElementById('dPlant').value  = plant.name;
        document.getElementById('dGrow').value   = plant.growthPeriod || 0;

        document.getElementById('dTitle').value  = '';
        document.getElementById('dDateText').textContent = startYmd;
        document.getElementById('dMemo').value   = '';
        document.getElementById('dColor').value  = 'green';

        positionModalUnderCell(dm, lastNativeEvent);
        dm.style.display = 'block';
    }
    window.closeDetail = function(){ document.getElementById('detailModal').style.display = 'none'; };

    // 저장(신규 등록): 화면용 제목은 '제목 (시작일)', 원본은 raw에
    document.getElementById('detailForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        const start    = document.getElementById('dDate').value;
        const plant    = document.getElementById('dPlant').value;
        const grow     = Number(document.getElementById('dGrow').value || 0);
        const titleRaw = document.getElementById('dTitle').value.trim();
        const memo     = document.getElementById('dMemo').value.trim();
        const colorKey = document.getElementById('dColor').value;

        if (!titleRaw) { alert('제목을 입력하세요.'); return; }

        const csrf = getCsrf();
        const headers = { 'Content-Type': 'application/json' };
        if (csrf) headers[csrf.header] = csrf.token;

        try {
            const res = await fetch(`${window.APP_CTX || ''}/calendar/save.do`, {
                method: 'POST',
                headers,
                credentials: 'include',
                body: JSON.stringify({
                    plants_name: plant,
                    start_date : start,
                    title: titleRaw,
                    memo,
                    color: colorKey
                })
            });
            const data = await res.json().catch(() => ({ ok: false }));
            if (!res.ok || !data.ok) throw new Error('저장 실패');

            const days = grow > 0 ? grow + 1 : 1;
            const endYmdExclusive = toLocalYMD(addDaysLocal(start, days));
            const hex = COLOR_MAP[colorKey] || '#eaeaea';

            cal.createEvents([{
                id: String(Date.now()),   // 임시 ID(재조회 시 DB PK로 대체 가능)
                calendarId: 'plant',
                title: `${titleRaw} (${start})`, // 화면용
                start: start,
                end: endYmdExclusive,
                isAllday: true,
                category: 'allday',
                backgroundColor: hex,
                borderColor: hex,
                raw: { dbTitle: titleRaw, memo, start } // 모달용 원본
            }]);

            // 필요 시 서버 PK 동기화를 위해 loadEvents() 호출
            // await loadEvents();

            closeDetail();
        } catch (err) {
            alert('저장 중 오류가 발생했습니다.');
            console.error(err);
        }
    });

    // 상세 모달(보기/수정/삭제)
    let currentEvent = null;

    function setViewMode(readonly) {
        const titleEl = document.getElementById('vTitle');
        const memoEl  = document.getElementById('vMemo');
        titleEl.readOnly = readonly;
        if (memoEl) memoEl.readOnly = readonly;

        document.getElementById('btnEdit').style.display   = readonly ? ''  : 'none';
        document.getElementById('btnDelete').style.display = readonly ? ''  : 'none';
        document.getElementById('btnSave').style.display   = readonly ? 'none' : '';
        document.getElementById('btnCancel').style.display = readonly ? 'none' : '';
    }

    // 막대 클릭 → 상세 모달: DB 원본(title, memo)으로 표시
    cal.on('clickEvent', ({ event, nativeEvent }) => {
        const modal = document.getElementById('eventDetailModal');

        document.getElementById('vId').value    = event?.id || '';
        document.getElementById('vTitle').value = event?.raw?.dbTitle ?? '';
        document.getElementById('vMemo').value  = event?.raw?.memo ?? '';

        currentEvent = event;
        setViewMode(true);

        positionModalUnderCell(modal, nativeEvent);
        modal.style.display = 'block';
    });

    // 수정
    document.getElementById('btnEdit').addEventListener('click', () => {
        setViewMode(false);
        document.getElementById('vTitle').focus();
    });

    // 취소(원복)
    document.getElementById('btnCancel').addEventListener('click', () => {
        if (!currentEvent) return;
        document.getElementById('vTitle').value = currentEvent?.raw?.dbTitle ?? '';
        document.getElementById('vMemo').value  = currentEvent?.raw?.memo ?? '';
        setViewMode(true);
    });

    // 저장(수정 반영): 서버에서 UPD_DATE=SYSDATE 갱신, 화면은 제목(시작일)로 재조합
    document.getElementById('btnSave').addEventListener('click', async () => {
        if (!currentEvent) return;

        const id    = document.getElementById('vId').value;
        const title = document.getElementById('vTitle').value.trim();
        const memo  = document.getElementById('vMemo').value.trim();
        if (!title) { alert('제목을 입력하세요.'); return; }

        const csrf = getCsrf();
        const headers = { 'Content-Type': 'application/json' };
        if (csrf) headers[csrf.header] = csrf.token;

        try {
            const res = await fetch(`${window.APP_CTX||''}/calendar/update.do`, {
                method: 'POST', headers, credentials:'include',
                body: JSON.stringify({ id, title, memo }) // 서버에서 UPD_DATE = SYSDATE 처리
            });
            const data = await res.json().catch(()=>({ok:false}));
            if (!res.ok || !data.ok) throw new Error('update failed');

            // 시작일 확보 후 화면용 제목 재생성
            const startYmd = typeof currentEvent.raw?.start === 'string'
                ? currentEvent.raw.start
                : toLocalYMD(currentEvent.start?.toDate ? currentEvent.start.toDate() : new Date(currentEvent.start));

            cal.updateEvent(currentEvent.id, currentEvent.calendarId, {
                title: `${title} (${startYmd})`,            // 화면용
                raw: { ...(currentEvent.raw||{}), dbTitle: title, memo } // 원본 갱신
            });

            setViewMode(true);
        } catch (e) {
            alert('수정 중 오류가 발생했습니다.');
            console.error(e);
        }
    });

    // 삭제
    document.getElementById('btnDelete').addEventListener('click', async () => {
        if (!currentEvent) return;
        if (!confirm('이 일정을 삭제할까요?')) return;

        const csrf = getCsrf();
        const headers = { 'Content-Type': 'application/json' };
        if (csrf) headers[csrf.header] = csrf.token;

        try {
            const res = await fetch(`${window.APP_CTX||''}/calendar/delete.do`, {
                method: 'POST', headers, credentials:'include',
                body: JSON.stringify({ id: currentEvent.id })
            });
            const data = await res.json().catch(()=>({ok:false}));
            if (!res.ok || !data.ok) throw new Error('delete failed');

            cal.deleteEvent(currentEvent.id, currentEvent.calendarId);
            currentEvent = null;
            closeEventDetail();
        } catch (e) {
            alert('삭제 중 오류가 발생했습니다.');
            console.error(e);
        }
    });

    window.closeEventDetail = function () {
        document.getElementById('eventDetailModal').style.display = 'none';
    };

    // 모달 외부 클릭/ESC 닫기
    (function enableOutsideClose() {
        const searchModal = document.getElementById('plantSearchModal');
        const detailModal = document.getElementById('detailModal');
        const viewModal   = document.getElementById('eventDetailModal');

        [searchModal, detailModal, viewModal].forEach(m => {
            if (!m) return;
            m.addEventListener('mousedown', e => e.stopPropagation());
            m.addEventListener('touchstart', e => e.stopPropagation(), { passive: true });
        });

        document.addEventListener('mousedown', (e) => {
            const isOpen = (m) => m && m.style.display === 'block';
            const isOutside = (m, t) => m && !m.contains(t);
            const t = e.target;

            if (isOpen(searchModal) && isOutside(searchModal, t)) closeModal();
            if (isOpen(detailModal) && isOutside(detailModal, t)) closeDetail();
            if (isOpen(viewModal)   && isOutside(viewModal,   t)) closeEventDetail();
        }, true);

        document.addEventListener('keydown', (e) => {
            if (e.key !== 'Escape') return;
            if (searchModal && searchModal.style.display === 'block') closeModal();
            if (detailModal && detailModal.style.display === 'block') closeDetail();
            if (viewModal   && viewModal.style.display   === 'block') closeEventDetail();
        });
    })();

    // 제목 중복 숨김
    const containerEl = document.querySelector('#calendar');
    const mo = new MutationObserver((mutations) => {
        mutations.forEach((m) => {
            m.addedNodes.forEach((node) => {
                if (!(node instanceof HTMLElement)) return;
                const titles = node.matches('.toastui-calendar-event-title')
                    ? [node]
                    : node.querySelectorAll?.('.toastui-calendar-event-title') || [];
                titles.forEach((titleEl) => {
                    const text = (titleEl.textContent || '').trim();
                    if (!text) return;
                    if (seenTitles.has(text)) titleEl.textContent = '';
                    else seenTitles.add(text);
                });
            });
        });
    });
    mo.observe(containerEl, { childList: true, subtree: true });
});
