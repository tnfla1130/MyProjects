package org.spring.projectjs.jdbc;

import java.sql.Date;
import lombok.Data;

@Data
public class BoardNoticeDTO {
    private String notice_idx;
    private String notice_title;
    private String notice_content;
    private int notice_visitcount;
    private Date notice_date;
    private String writer;
    private String ofile1;
    private String sfile1;
    private String ofile2;
    private String sfile2;
    private String ofile3;
    private String sfile3;
}
