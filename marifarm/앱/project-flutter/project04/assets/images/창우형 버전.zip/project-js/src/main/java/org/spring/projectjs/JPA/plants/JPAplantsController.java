package org.spring.projectjs.JPA.plants;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class JPAplantsController {
    private final JPAplantsRepository repository;

    // 루트 페이지
    @GetMapping("/root")
    public String redirectToForm() {
        return "redirect:/form";
    }

    @GetMapping("/env.do")
    public String env() {
        return "env";
    }

    // 추천 폼 페이지
    @GetMapping("/form")
    public String showForm() {
        return "recommend-form";
    }

    // 🔸 추천 처리 - easy 또는 custom 타입 처리
    @GetMapping("/recommend")
    public String recommend(
            @RequestParam("type") String type,
            @RequestParam(value = "temperature", required = false) Integer temperature,
            @RequestParam(value = "difficulty", required = false) Integer difficulty,
            @RequestParam(value = "growDays", required = false) Integer growDays,
            Model model
    ) {
        List<JPAplants> results;

        if ("easy".equals(type)) {
            results = repository.findByDifficultyLessThanEqual(2);

        } else if ("custom".equals(type)) {
            if (temperature == null || difficulty == null || growDays == null) {
                model.addAttribute("error", "추천 조건이 누락되었습니다.");
                return "recommend-form";
            }

            // 느슨한 조건 범위
            int tempRange = 5;
            int minTemp = temperature - tempRange;
            int maxTemp = temperature + tempRange;

            int growRange = 20;
            int maxGrow = growDays + growRange;

            results = repository.findByMinTempGreaterThanEqualAndMaxTempLessThanEqualAndDifficultyLessThanEqualAndMaxGrowDaysLessThanEqual(
                    minTemp, maxTemp, difficulty, maxGrow
            );
        } else {
            model.addAttribute("error", "유효하지 않은 추천 타입입니다.");
            return "recommend-form";
        }

        model.addAttribute("plantList", results);
        model.addAttribute("recommendType", type);
        return "recommend-result";
    }

    // 🔹 전체 식물 목록 + 이름 검색
    @GetMapping("/plants")
    public String showAllPlants(
            @RequestParam(value = "keyword", required = false) String keyword,
            Model model
    ) {
        List<JPAplants> results;

        if (keyword != null && !keyword.trim().isEmpty()) {
            results = repository.findByNameContainingIgnoreCase(keyword);
        } else {
            results = repository.findAll();
        }

        model.addAttribute("plantList", results);
        model.addAttribute("keyword", keyword);
        return "plant-list";
    }


}