package org.spring.projectjs.JPA.board;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JPAboardService {

    JPAboardRepository boardRepository;

    //생성자 주입
    public JPAboardService(JPAboardRepository boardRepository) {
        this.boardRepository = boardRepository;
    }

    //보드 전체 조회
    public List<JPAboard> getAllBoard() {
        return boardRepository.findAll();
    }

    //보드 게시글 등록
    public JPAboard addBoard(JPAboard board) {
        JPAboard addedBoard = boardRepository.save(board);

        return addedBoard;
    }

    //게시글 삭제
    public void deleteBoard(Long boardIdx) {
        if (!boardRepository.existsById(boardIdx)) {
            throw new RuntimeException("게시글이 없습니다. id=" + boardIdx);
        }
        boardRepository.deleteById(boardIdx);
    }
    //게시글 개별 조회(게시글 제목으로 서칭 가능)
    public JPAboard getBoardboardTitle(String boardTitle) {
        return boardRepository.findBoardByBoardTitle(boardTitle)
                .orElseThrow(() -> new RuntimeException("게시글이 없습니다. id=" + boardTitle));
    }

    //게시글 수정
    @Transactional
    public JPAboard updateBoard(Long boardIdx, JPAboard updatedBoard) {
        JPAboard existingBoard = boardRepository.findById(boardIdx)
                .orElseThrow(() -> new RuntimeException("회원이 없습니다. id=" + boardIdx));
        // 필요한 필드만 수정 (예시)
        existingBoard.setBoardIdx(updatedBoard.getBoardIdx());
        existingBoard.setBoardDate(updatedBoard.getBoardDate());
        existingBoard.setBoardId(updatedBoard.getBoardId());
        existingBoard.setBoardContent(updatedBoard.getBoardContent());
        existingBoard.setBoardTitle(updatedBoard.getBoardTitle());
        existingBoard.setVisitCount(updatedBoard.getVisitCount());

        return existingBoard;
    }
    //게시글 사진 업로드
    //게시글 사진 다운로드
    //게시글 검색
    //게시글 좋아요
    //게시글 싫어요
    //게시글 조회수
}

