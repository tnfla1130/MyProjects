package org.spring.projectjs.JPA.plants;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "plants")
@Getter
@Setter
public class JPAplants {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(name = "english_name")
    private String englishName;

    // 난이도 (1 ~ 5)
    private Integer difficulty;

    @Column(name = "min_temp")
    private Integer minTemp;

    @Column(name = "max_temp")
    private Integer maxTemp;

    @Column(name = "min_grow_days")
    private Integer minGrowDays;

    @Column(name = "max_grow_days")
    private Integer maxGrowDays;

}
