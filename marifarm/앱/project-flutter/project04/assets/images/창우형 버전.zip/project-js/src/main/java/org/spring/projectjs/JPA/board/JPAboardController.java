package org.spring.projectjs.JPA.board;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/board")
public class JPAboardController {

    JPAboardService boardService;

    //생성자
    public JPAboardController(JPAboardService boardService) {
        this.boardService = boardService;
    }

    //게시판 전체 조회
    @GetMapping
    public List<JPAboard>getAllBoard() {
        return boardService.getAllBoard();
    }

    //게시판 등록
    @PostMapping
    public JPAboard addboard(@RequestBody JPAboard board) {
        return boardService.addBoard(board);
    }
    //게시판 개별 조회
    @GetMapping("/search/{boardTitle}")
    public JPAboard getBoardTitle(@PathVariable String boardTitle) {
        return  boardService.getBoardboardTitle(boardTitle);
    }

    //게시판 삭제
    @DeleteMapping("/delete/{boardIdx}")
    public void deleteBoard(@PathVariable Long boardIdx) {
        boardService.deleteBoard(boardIdx);}

    //게시판 수정
    @PutMapping("/edit/{boardIdx}")
    public JPAboard editBoard(@PathVariable Long boardIdx, @RequestBody JPAboard board) {
        return boardService.updateBoard(boardIdx, board);
    }

}
