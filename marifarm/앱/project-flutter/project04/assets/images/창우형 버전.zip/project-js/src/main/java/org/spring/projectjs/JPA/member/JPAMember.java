package org.spring.projectjs.JPA.member;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity //엔티티, DB에서 받은 값을 저장하는 곳
@Table(name = "member")
public class JPAMember {

    //일련번호
    @Id //기본키를 지정
    @GeneratedValue(strategy = GenerationType.IDENTITY) //memberidx의 값이 값이 추가될때마다 자동으로 올라감
    private Long memberIdx;

    //아이디
    @Column(nullable = false, unique = true) //널값 지정, 아이디는 한개의 값밖에 존재할 수 없다
    private String userId;

    //비밀번호
    @Column(nullable = false)
    private String password;

    //이메일
    @Column(nullable = false)
    private String email;

    //전화번호
    private String phone;

    //재화
    @Column(nullable = false)
    private int point;

    //별명
    @Column(nullable = false, unique = true)
    private String nickname;

    //등록일
    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP) //날짜와 시간 전부 가져오기
    private Date postdate;

    //계정 권한
    @Column(nullable = false)
    private String memberAuth;

    //도메인(이메일 뒤에 붙는 자료)
    @Column(nullable = false)
    private String domain;


}
