package org.spring.projectjs.jdbc;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface IBoardNotice {
	
	//전체 개수 및 목록 가져오기 상세보기
	public int notice_totalCount(ParameterDTO parameterDTO);
	public ArrayList<BoardDTO> notice_listPage(ParameterDTO parameterDTO);
	public BoardNoticeDTO notice_view(BoardNoticeDTO boardNoticeDTO);
	
	//방문자수 좋아요 싫어요
	public int notice_board_visitcounter(String idx);
	public int notice_board_good_count(String num);
	public int notice_board_worse_count(String num);
	
	//댓글등록
	public int notice_comment_insert( String board_idx, String comment_content );
	public ArrayList<CommentDTO> notice_comment_select( String board_idx );
	public int notice_comment_delete(String comment_idx);
	public int notice_comment_write_del(String board_idx);	
	
}
