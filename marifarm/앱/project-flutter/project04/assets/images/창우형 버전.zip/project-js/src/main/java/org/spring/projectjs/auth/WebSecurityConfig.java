package org.spring.projectjs.auth;

import javax.sql.DataSource;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import jakarta.servlet.DispatcherType;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

	@Autowired
	public MyAuthFailureHandler myAuthFailureHandler;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

	@Bean
    SecurityFilterChain filterChain(HttpSecurity http, UserDetailsService uds) throws Exception {
        JwtAuthenticationFilter jwtFilter = new JwtAuthenticationFilter(jwtTokenProvider, uds);

		http
				.csrf(csrf -> csrf.disable())
				.cors(withDefaults()) // cors 설정 활성화
				.authorizeHttpRequests(request -> request
						.dispatcherTypeMatchers(DispatcherType.FORWARD).permitAll()
						.requestMatchers("/", "/regist.do", "/checkDuplicate.do", "/checkNicknameDuplicate.do"
                                    ).permitAll()
						.requestMatchers("/css/**", "/js/**", "/images/**").permitAll()
						.requestMatchers("/guest/**").permitAll()
						.requestMatchers("/member/**").hasAnyRole("USER", "ADMIN")
						.requestMatchers("/admin/**").hasRole("ADMIN")
						.requestMatchers("/api/member/**").permitAll()
						.requestMatchers("/api/board/**").permitAll()
                        .requestMatchers("/api/auth/**").permitAll()
						.anyRequest().permitAll()
				)
				.formLogin(formLogin -> formLogin
						.loginPage("/myLogin.do")
						.loginProcessingUrl("/myLoginAction.do")
						.defaultSuccessUrl("/", true)
						.failureHandler(myAuthFailureHandler)
						.usernameParameter("my_id")
						.passwordParameter("my_pass")
						.permitAll()
				)
				.logout(logout -> logout
						.logoutUrl("/myLogout.do")
						.logoutSuccessUrl("/")
						.permitAll()
				)
				.exceptionHandling(exceptions -> exceptions
						.authenticationEntryPoint((request, response, authException) -> {
							if ("OPTIONS".equals(request.getMethod())) {
								response.setStatus(HttpServletResponse.SC_OK);
							} else {
								response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
							}
						})
						.accessDeniedPage("/denied.do")
				);
        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

		return http.build();
	}

	// JDBC 인증 설정
    @Bean
    UserDetailsService userDetailsService(DataSource dataSource) {
        JdbcUserDetailsManager manager = new JdbcUserDetailsManager(dataSource);
        manager.setUsersByUsernameQuery(
                "select user_id, password, 1 as enabled from member where user_id = ?"
        );
        // DB에 ROLE_USER / ROLE_ADMIN 형태로 이미 저장됨
        manager.setAuthoritiesByUsernameQuery(
                "select user_id, member_auth from member where user_id = ?"
        );
        return manager;
    }
    @Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

	// CORS 설정 추가
	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowedOrigins(List.of("http://localhost:5173","http://192.168.0.21:*")); // React 개발 서버 허용
		config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
		config.setAllowedHeaders(List.of("*"));
		config.setAllowCredentials(true); // 쿠키 포함 요청 허용

		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", config);
		return source;
	}

//    @Bean
//    CorsConfigurationSource corsConfigurationSource() {
//        CorsConfiguration cfg = new CorsConfiguration();
//        // 개발 편의: localhost, 사내 IP(192.168.0.21) 모든 포트 허용
//        cfg.setAllowedOriginPatterns(List.of(
//                "http://localhost:*",
//                "http://192.168.0.21:*"
//        ));
//        cfg.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS"));
//        cfg.setAllowedHeaders(List.of("Authorization","Content-Type"));
//        cfg.setAllowCredentials(true);
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**", cfg);
//        return source;
//    }


}