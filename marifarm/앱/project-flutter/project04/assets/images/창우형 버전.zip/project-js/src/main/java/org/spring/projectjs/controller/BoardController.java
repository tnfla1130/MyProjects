package org.spring.projectjs.controller;

import java.io.File;
import java.net.URLEncoder;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.*;
import org.spring.projectjs.jdbc.*;
import org.spring.projectjs.utils.MyFunctions;
import jakarta.servlet.http.*;
import jakarta.servlet.http.Part;
import utils.CookieManager;
import utils.FileUtil;
import utils.PagingUtil;

@Controller
public class BoardController {

    @Autowired
    IBoard dao;

    @RequestMapping("/")
    public String main() {
        return "main";
    }

    // ===================== [댓글 처리] =====================

    @GetMapping("/commentDelete.do")
    public String commentDelete(HttpServletRequest req, CommentDTO comment, Model model) {
        String board_idx = req.getParameter("board_idx");
        String comment_idx = req.getParameter("comment_idx");
        int pageNum = parseIntOrDefault(req.getParameter("pageNum"), 1);
        String searchField = optionalParam(req.getParameter("searchField"));
        String searchKeyword = optionalParam(req.getParameter("searchKeyword"));

        dao.comment_delete(comment_idx);

        return "redirect:board/boardView.do?board_idx=" + board_idx + "&pageNum=" + pageNum +
                "&searchField=" + searchField + "&searchKeyword=" + URLEncoder.encode(searchKeyword);
    }

    @PostMapping("/commentWrite.do")
    public String commentWrite(HttpServletRequest req, CommentDTO comment, Model model) {
        String board_idx = req.getParameter("board_idx");
        String comment_content = req.getParameter("comment_content").replace("\r\n", "<br>");
        int pageNum = parseIntOrDefault(req.getParameter("pageNum"), 1);
        String searchField = optionalParam(req.getParameter("searchField"));
        String searchKeyword = optionalParam(req.getParameter("searchKeyword"));

        dao.comment_insert(board_idx, comment_content);

        return "redirect:board/boardView.do?board_idx=" + board_idx + "&pageNum=" + pageNum +
                "&searchField=" + searchField + "&searchKeyword=" + URLEncoder.encode(searchKeyword);
    }

    // ===================== [목록] =====================

    @GetMapping({"/boardList.do", "/board/list"})
    public String boardList(Model model, HttpServletRequest req, ParameterDTO parameterDTO) {
        int totalCount = dao.totalCount(parameterDTO);
        int pageSize = 10, blockPage = 5;
        int pageNum = parseIntOrDefault(req.getParameter("pageNum"), 1);
        String searchField = optionalParam(req.getParameter("searchField"));
        String searchKeyword = optionalParam(req.getParameter("searchKeyword"));

        int start = (pageNum - 1) * pageSize + 1;
        int end = pageNum * pageSize;

        parameterDTO.setStart(start);
        parameterDTO.setEnd(end);
        parameterDTO.setSearchField(searchField);
        parameterDTO.setSearchKeyword(searchKeyword);

        model.addAttribute("maps", Map.of(
            "totalCount", totalCount, "pageSize", pageSize, "pageNum", pageNum,
            "searchField", searchField, "searchKeyword", searchKeyword
        ));

        model.addAttribute("lists", dao.listPage(parameterDTO));
        model.addAttribute("pagingImg", PagingUtil.pagingImg(
                totalCount, pageSize, blockPage, pageNum,
                req.getContextPath() + "/boardList.do?", searchField, searchKeyword
        ));

        return "board/boardList";
    }

    // ===================== [글 등록] =====================

    @GetMapping("/boardWrite.do")
    public String boardWriteGET() {
        return "board/boardWrite";
    }

    @PostMapping("/boardWrite.do")
    public String boardWritePOST(HttpServletRequest req) {
        String board_title = req.getParameter("board_title");
        String board_content = req.getParameter("board_content");
        String board_id = req.getParameter("board_id");

        try {
            String uploadDir = ResourceUtils.getFile("classpath:static/uploads/").toPath().toString();
            Map<String, String> saveFileMap = FileUtil.uploadFile(req, uploadDir);

            BoardDTO board = new BoardDTO();
            board.setBoard_title(board_title);
            board.setBoard_content(board_content);
            board.setBoard_id(Integer.parseInt(board_id));

            int i = 1;
            for (String key : saveFileMap.keySet()) {
                if (i == 1) {
                    board.setOfile1(key);
                    board.setSfile1(saveFileMap.get(key));
                } else if (i == 2) {
                    board.setOfile2(key);
                    board.setSfile2(saveFileMap.get(key));
                } else if (i == 3) {
                    board.setOfile3(key);
                    board.setSfile3(saveFileMap.get(key));
                }
                i++;
            }

            dao.insert(board);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return "redirect:/boardList.do";
    }

    // ===================== [글 보기] =====================

    @GetMapping("/board/boardView.do")
    public String boardViewAlias2(HttpServletRequest req) {
        return "redirect:/boardView.do?board_idx=" + req.getParameter("board_idx");
    }

    @GetMapping("/boardView.do")
    public String boardView(HttpServletResponse resp, HttpServletRequest req, BoardDTO boardDTO, Model model) {
        String idx = req.getParameter("board_idx");
        int num = parseIntOrDefault(req.getParameter("num"), 0);

        String ckName = switch (num) {
            case 5 -> "good-" + idx;
            case 6 -> "worse-" + idx;
            default -> "visit-" + idx;
        };
        int result = cookieOneDay(req, model, resp, ckName);

        if (result == 1) {
            if (num == 5) dao.board_good_count(idx);
            else if (num == 6) dao.board_worse_count(idx);
            else dao.board_visitcounter(idx);
        }

        boardDTO.setBoard_idx(idx);
        boardDTO = dao.view(boardDTO);
        boardDTO.setBoard_content(boardDTO.getBoard_content().replace("\r\n", "<br>"));

        Map<String, String> maps = Map.of(
            "searchField", optionalParam(req.getParameter("searchField")),
            "searchKeyword", optionalParam(req.getParameter("searchKeyword")),
            "pageNum", optionalParam(req.getParameter("pageNum"))
        );

        List<String> cates = Arrays.asList(
            fileCheckName(boardDTO.getOfile1()),
            fileCheckName(boardDTO.getOfile2()),
            fileCheckName(boardDTO.getOfile3())
        );

        model.addAttribute("maps", new HashMap<>(maps));
        model.addAttribute("boardDTO", boardDTO);
        model.addAttribute("lists", dao.comment_select(idx));
        model.addAttribute("cate1", cates.get(0));
        model.addAttribute("cate2", cates.get(1));
        model.addAttribute("cate3", cates.get(2));

        return "board/boardView";
    }

    @GetMapping("/board/view")
    public String boardViewAlias(HttpServletRequest req) {
        return "redirect:/boardView.do?board_idx=" + req.getParameter("board_idx");
    }

    // ===================== [글 수정] =====================

    @GetMapping("/boardEdit.do")
    public String boardEdit(BoardDTO boardDTO, Model model) {
        boardDTO = dao.view(boardDTO);

        Map<String, Object> boardMap = new HashMap<>();
        boardMap.put("ofile1", boardDTO.getOfile1());
        boardMap.put("sfile1", boardDTO.getSfile1());
        boardMap.put("ofile2", boardDTO.getOfile2());
        boardMap.put("sfile2", boardDTO.getSfile2());
        boardMap.put("ofile3", boardDTO.getOfile3());
        boardMap.put("sfile3", boardDTO.getSfile3());
        boardMap.put("cate1", fileCheckName(boardDTO.getOfile1()));
        boardMap.put("cate2", fileCheckName(boardDTO.getOfile2()));
        boardMap.put("cate3", fileCheckName(boardDTO.getOfile3()));

        model.addAttribute("boardDTO", boardDTO);
        model.addAttribute("boardMap", boardMap);

        return "board/boardEdit";
    }

    @PostMapping("/board/edit")
    public String boardEditFinal(HttpServletRequest req) {
        String board_idx = req.getParameter("board_idx");
        String board_title = req.getParameter("board_title");
        String board_content = req.getParameter("board_content");

        dao.updateTitleContent(board_title, board_content, board_idx);
        BoardDTO board = dao.view(new BoardDTO(board_idx));

        try {
            String uploadDir = ResourceUtils.getFile("classpath:static/uploads/").toPath().toString();
            Map<String, String> saveFileMap = FileUtil.uploadFile(req, uploadDir);

            int slot = 1;
            for (String key : saveFileMap.keySet()) {
                String prevSfile = switch (slot) {
                    case 1 -> board.getSfile1();
                    case 2 -> board.getSfile2();
                    case 3 -> board.getSfile3();
                    default -> null;
                };
                if (prevSfile != null && !prevSfile.isEmpty())
                    FileUtil.deleteFile(req, uploadDir, prevSfile);

                BoardDTO fileDto = new BoardDTO();
                fileDto.setBoard_idx(board_idx);
                fileDto.setNum(slot);
                if (slot == 1) {
                    fileDto.setOfile1(key);
                    fileDto.setSfile1(saveFileMap.get(key));
                } else if (slot == 2) {
                    fileDto.setOfile2(key);
                    fileDto.setSfile2(saveFileMap.get(key));
                } else if (slot == 3) {
                    fileDto.setOfile3(key);
                    fileDto.setSfile3(saveFileMap.get(key));
                }
                dao.updateFile(fileDto);
                if (++slot > 3) break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return "redirect:/board/view?board_idx=" + board_idx;
    }

    // ===================== [기타 기능] =====================

    // 다운로드
    @GetMapping("/boardDownload.do")
    public void boardDownload(HttpServletRequest req, HttpServletResponse res) {
        try {
            String uploadDir = ResourceUtils.getFile("classpath:static/uploads/").toPath().toString();
            FileUtil.download(req, res, uploadDir, req.getParameter("sfile"), req.getParameter("ofile"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 삭제
    @PostMapping("/boardDelete.do")
    public String boardDelete(HttpServletRequest req) {
        String board_idx = req.getParameter("board_idx");

        // 🔥 삭제 전에 게시글 정보 조회
        BoardDTO board = dao.view(new BoardDTO(board_idx));

        dao.comment_write_del(board_idx);   // 댓글 먼저 삭제
        dao.delete(board_idx);              // 게시글 삭제

        // 🔥 파일 삭제 시 실제 파일명 사용
        if (board != null) {
            deleteFiles(req, board.getSfile1(), board.getSfile2(), board.getSfile3());
        }

        return "redirect:/boardList.do";
    }

    
    @PostMapping("/boardDeleteFileOne.do")
    public String deleteFileOne(HttpServletRequest req) {
        String board_idx = req.getParameter("board_idx");
        String sfile = req.getParameter("sfile");
        String imgCount = req.getParameter("imgCount");

        dao.deleteFileOne(board_idx, imgCount);
        deleteFile(req, sfile);
        return "redirect:board/boardEdit.do?board_idx=" + board_idx;
    }

    @PostMapping("/boardDeleteFileAll.do")
    public String boardDeleteFileAll(HttpServletRequest req) {
        String board_idx = req.getParameter("board_idx");
        BoardDTO board = dao.view(new BoardDTO(board_idx));
        deleteFiles(req, board.getSfile1(), board.getSfile2(), board.getSfile3());
        dao.boardDeleteFileAll(board_idx);
        return "redirect:board/boardEdit.do?board_idx=" + board_idx;
    }

    // ===================== [파일 업로드 샘플] =====================

    @GetMapping("/fileUpload.do")
    public String fileUpload() {
        return "fileUpload";
    }

    @PostMapping("/uploadProcess.do")
    public String uploadProcess(HttpServletRequest req, Model model) {
        try {
            String uploadDir = ResourceUtils.getFile("classpath:static/uploads/").toPath().toString();
            Part part = req.getPart("ofile");
            String partHeader = part.getHeader("content-disposition");
            String originalFileName = partHeader.split("filename=")[1].trim().replace("\"", "");
            if (!originalFileName.isEmpty()) part.write(uploadDir + File.separator + originalFileName);
            String savedFileName = MyFunctions.renameFile(uploadDir, originalFileName);

            model.addAttribute("originalFileName", originalFileName);
            model.addAttribute("savedFileName", savedFileName);
            model.addAttribute("title", req.getParameter("title"));
            model.addAttribute("cate", req.getParameterValues("cate"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "fileUploadOk";
    }

    // ===================== [유틸 메서드] =====================

    public String fileCheckName(String fileName) {
        if (fileName == null || fileName.isEmpty()) return "etc";
        String ext = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
        List<String> img = List.of("jpg", "jpeg", "gif", "png", "bmp", "webp");
        List<String> vid = List.of("avi", "mp4", "mov", "wmv", "flv", "mkv");
        List<String> aud = List.of("mp3", "wav", "ogg", "aac", "flac");
        return img.contains(ext) ? "img" : vid.contains(ext) ? "video" : aud.contains(ext) ? "audio" : "etc";
    }

    public int cookieOneDay(HttpServletRequest req, Model model, HttpServletResponse resp, String ckName) {
        if (CookieManager.readCookie(req, ckName).equals("")) {
            CookieManager.makeCookie(resp, ckName, "true", 86400);
            model.addAttribute("message", "쿠키생성&조회수update");
            return 1;
        }
        model.addAttribute("message", "하루동안처리안함");
        return 2;
    }

    private void deleteFile(HttpServletRequest req, String sfile) {
        try {
            String uploadDir = ResourceUtils.getFile("classpath:static/uploads/").toPath().toString();
            if (sfile != null && !sfile.isEmpty()) FileUtil.deleteFile(req, uploadDir, sfile);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void deleteFiles(HttpServletRequest req, String... files) {
        Arrays.stream(files).forEach(f -> deleteFile(req, f));
    }

    private int parseIntOrDefault(String param, int defaultVal) {
        try {
            return (param == null || param.isEmpty()) ? defaultVal : Integer.parseInt(param);
        } catch (Exception e) {
            return defaultVal;
        }
    }

    private String optionalParam(String param) {
        return (param == null || param.isEmpty()) ? "" : param;
    }
}
