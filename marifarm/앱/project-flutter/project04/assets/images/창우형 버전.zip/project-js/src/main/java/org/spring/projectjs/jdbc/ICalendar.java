package org.spring.projectjs.jdbc;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ICalendar {
    List<PlantDTO> searchPlantName(@Param("keyword") String keyword);

    PlantDTO findPlantName(@Param("name") String name);

    int insertCalendar(CalendarDTO calendarDTO);

    List<CalendarDTO> listCalendarByRange(@Param("member_id") String memberId, @Param("start") String startYmd,
                                          @Param("end") String endYmd
    );

    int updateCalendar(@Param("id") int id, @Param("title") String title, @Param("memo") String memo,
                       @Param("memberId") String memberId);

    int deleteCalendar(@Param("id") int id, @Param("memberId") String memberId);

    int updateCalendarDate(@Param("id") int id, @Param("startDate") String startDate, @Param("memberId") String memberId);
}
