/**
 * 
 */


let imageList = [];  // 이미지 파일명을 담을 배열
let currentIndex = 0;

// 페이지가 로드되면 JSTL로부터 이미지 리스트를 초기화
window.onload = function() {
    imageList = [
        <c:forEach var="img" items="${imageList}" varStatus="status">
            "${img}"<c:if test="${!status.last}">,</c:if>
        </c:forEach>
    ];
    updateImage(); // 초기 이미지 로드
}

function updateImage() {
    if (imageList.length > 0) {
        const imgTag = document.getElementById("img01");
        imgTag.src = "./uploads/" + imageList[currentIndex];
    }
}

function nextImage() {
    if (imageList.length > 0) {
        currentIndex = (currentIndex + 1) % imageList.length;
        updateImage();
    }
}

function prevImage() {
    if (imageList.length > 0) {
        currentIndex = (currentIndex - 1 + imageList.length) % imageList.length;
        updateImage();
    }
}

function transactionEdit(idx){
	//alert("수정 idx = " + idx);
	if( confirm("수정 하시겠습니까?") ){
		location.href='./transactionEdit.do?transaction_idx='+idx;
	}
}

function transaction_deletePost( idx, sfile1, sfile2, sfile3 ){	
	
	//alert( idx + " : " + sfile1 + " : " + sfile2 + " : " + sfile3 );	
	//alert("11111111");	
	
	var f = document.transactionDeleteFrm;
	f.action="/transaction_Delete.do";
	f.method="post";
	f.transaction_idx.value=idx;
	f.sfile1.value=sfile1;
	f.sfile2.value=sfile2;
	f.sfile3.value=sfile3;
	
	if( confirm("삭제하시겠습니까?") ){
		f.submit();
	}
}

function transaction_purchase(idx){
	//alert("transaction_purchase = idx = " + idx);
	
	if( confirm("구매 하시겠습니까?") ){
		location.href='./transaction_purchase.do?transaction_idx='+idx;
	}
	
}