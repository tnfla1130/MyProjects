package org.spring.projectjs.JPA.plants;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

@Service
@RequiredArgsConstructor
public class JPAplantsService {

    private final JPAplantsRepository repository;

    @PostConstruct
    private void init() throws Exception {
        System.out.println("=== CSV 로딩 시작 ===");

        if (repository.count() > 0) {
            System.out.println("=== CSV 로딩 생략 (이미 데이터 존재) ===");
            return;
        }

        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                getClass().getResourceAsStream("/static/data/plants.csv"), StandardCharsets.UTF_8))) {

            br.readLine(); // ✅ 첫 줄(헤더) 건너뛰기
            int count = 0;
            String line;

            while ((line = br.readLine()) != null) {
                String[] arr = line.split(",");
                if (arr.length < 9) {
                    System.err.println("⚠️ 잘못된 CSV 라인: " + line);
                    continue;
                }

                try {
                    JPAplants p = new JPAplants();
                    p.setName(arr[0].trim());           // 식물명
                    p.setEnglishName(arr[1].trim());    // 영문명

                    // ✅ 키우기 난이도
                    p.setDifficulty(safeParseInt(arr[3]));

                    // ✅ 적정 온도 (min~max)
                    String[] tempRange = arr[4].split("~");
                    p.setMinTemp(safeParseInt(tempRange[0]));
                    p.setMaxTemp(tempRange.length > 1 ? safeParseInt(tempRange[1]) : 0);

                    // ✅ 성장 기간 (min~max)
                    String[] growRange = arr[6].split("~");
                    p.setMinGrowDays(safeParseInt(growRange[0]));
                    p.setMaxGrowDays(growRange.length > 1 ? safeParseInt(growRange[1]) : 0);

                    repository.save(p);
                    count++;
                } catch (Exception e) {
                    System.err.println("⚠️ CSV 로딩 중 오류 발생 (라인 건너뜀): " + line);
                    e.printStackTrace();
                }
            }

            System.out.println("=== CSV 로딩 완료, 저장된 개수: " + count + " ===");
        }
    }

    private int safeParseInt(String value) {
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }


}
