package com.example.controller;

import java.util.*;
import jakarta.servlet.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.dto.NoticeDTO;
import com.example.service.NoticeService;

@Controller
public class NoticeController {

    @Autowired
    NoticeService noticeService;

    @GetMapping("/noticeList.do")
    public String noticeList(HttpServletRequest req, Model model) {
        String searchField = Optional.ofNullable(req.getParameter("searchField")).orElse("");
        String searchKeyword = Optional.ofNullable(req.getParameter("searchKeyword")).orElse("");

        Map<String, Object> params = new HashMap<>();
        params.put("searchField", searchField);
        params.put("searchKeyword", searchKeyword);

        List<NoticeDTO> lists = noticeService.list(params);
        model.addAttribute("lists", lists);
        model.addAttribute("searchField", searchField);
        model.addAttribute("searchKeyword", searchKeyword);

        return "board/noticeList";
    }

    @GetMapping("/noticeView.do")
    public String noticeView(HttpServletRequest req, Model model) {
        String idx = req.getParameter("notice_idx");
        noticeService.visitCount(idx);

        NoticeDTO dto = noticeService.view(idx);
        dto.setNotice_content(dto.getNotice_content().replace("\r\n", "<br>"));

        model.addAttribute("noticeDTO", dto);
        return "board/noticeView";
    }

    @GetMapping("/noticeWrite.do")
    public String noticeWriteForm() {
        return "board/noticeWrite";
    }

    @PostMapping("/noticeWrite.do")
    public String noticeWrite(NoticeDTO dto, HttpServletRequest req) {
        noticeService.write(dto);
        return "redirect:/noticeList.do";
    }

    @GetMapping("/noticeEdit.do")
    public String noticeEditForm(HttpServletRequest req, Model model) {
        String idx = req.getParameter("notice_idx");
        NoticeDTO dto = noticeService.view(idx);
        model.addAttribute("noticeDTO", dto);
        return "board/noticeEdit";
    }

    @PostMapping("/noticeEdit.do")
    public String noticeEdit(NoticeDTO dto) {
        noticeService.edit(dto);
        return "redirect:/noticeView.do?notice_idx=" + dto.getNotice_idx();
    }

    @GetMapping("/noticeDelete.do")
    public String noticeDelete(HttpServletRequest req) {
        String idx = req.getParameter("notice_idx");
        noticeService.delete(idx);
        return "redirect:/noticeList.do";
    }
}
