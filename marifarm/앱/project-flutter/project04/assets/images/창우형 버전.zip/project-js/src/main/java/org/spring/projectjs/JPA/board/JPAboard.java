package org.spring.projectjs.JPA.board;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity
@Table(name = "board")
public class JPAboard {

    //일련번호
    @Id //기본키
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int boardIdx;

    //게시판 이름
    @Column(nullable = false)
    private String boardTitle;

    //게시판 내용
    @Column(nullable = false)
    private String boardContent;

    //방문횟수
    @Column(nullable = false)
    private int visitCount;

    //게시글 등록일
    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP) //날짜와 시간 전부 가져오기
    private Date boardDate;

    //게시글 id 1=공지사항, 2.자유
    @Column(nullable = false)
    private int boardId;

    //좋아요
    @Column(nullable = false)
    private int boardGood;

    //싫어요
    @Column(nullable = false)
    private int boardWorse;

    //사진1
    private String ofile1;
    //사진2
    private String ofile2;
    //사진3
    private String ofile3;
    //사진1save
    private String sfile1;
    //사진2save
    private String sfile2;
    //사진3save
    private String sfile3;
}
