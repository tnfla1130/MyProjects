package org.spring.projectjs.jdbc;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CalendarService {

    @Autowired
    private ICalendar calendarMapper;

    public List<PlantDTO> search(String keyword) {
        return calendarMapper.searchPlantName(keyword);
    }

    public PlantDTO find(String name) {
        return calendarMapper.findPlantName(name);
    }

    @Transactional
    public int insertCalendar(CalendarDTO calendarDTO) {
        return calendarMapper.insertCalendar(calendarDTO);
    }

    public List<CalendarDTO> list(String memberId, String startYmd, String endYmd) {
        return calendarMapper.listCalendarByRange(memberId, startYmd, endYmd);
    }

    public int update(int id, String title, String memo, String memberId){
        return calendarMapper.updateCalendar(id, title, memo, memberId);
    }
    public int delete(int id, String memberId){
        return calendarMapper.deleteCalendar(id, memberId);
    }

    @Transactional
    public int updateCalendarDate(int id, String startDate, String memberId) {
        return calendarMapper.updateCalendarDate(id, startDate, memberId);
    }
}
