package org.spring.projectjs.jdbc;

import lombok.Data;

@Data
public class PlantDTO {
    private String name;
    private int max_grow_days;
}
