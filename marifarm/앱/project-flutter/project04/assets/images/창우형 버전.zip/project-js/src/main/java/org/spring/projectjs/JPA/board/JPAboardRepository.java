package org.spring.projectjs.JPA.board;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface JPAboardRepository extends JpaRepository<JPAboard,Long> {

    Optional<JPAboard> findBoardByBoardTitle(String boardTitle);
}
