// 이메일 도메인 선택 핸들러
function handleDomainSelect(value) {
  const domainInput = document.getElementById('domainInput');
  if (value) {
    domainInput.value = value;
    domainInput.readOnly = true;
  } else {
    domainInput.value = '';
    domainInput.readOnly = false;
  }
}

// 중복확인 상태
let isIdChecked = false;
let isNicknameChecked = false;

/* =============== 공통 유틸 =============== */
function isEmpty(value) {
  return value == null || String(value).trim() === '';
}

/* =============== 중복확인 =============== */
function checkIdDuplicate(btnEl) {
  const userIdInput = document.querySelector('input[name="user_id"]');
  const messageDiv = document.getElementById('idMessage');
  const userId = userIdInput.value.trim();

  if (!userId) {
    messageDiv.textContent = '아이디를 입력해주세요.';
    messageDiv.className = 'validation-message error';
    userIdInput.focus();
    return;
  }

  btnEl.disabled = true;
  const original = btnEl.textContent;
  btnEl.textContent = '확인중...';

  fetch('/checkDuplicate.do', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'user_id=' + encodeURIComponent(userId)
  })
    .then(r => r.json())
    .then(data => {
      if (data.available) {
        messageDiv.textContent = data.message || '사용가능합니다.';
        messageDiv.className = 'validation-message success';
        isIdChecked = true;
      } else {
        messageDiv.textContent = data.message || '아이디를 다시 입력해주세요.';
        messageDiv.className = 'validation-message error';
        isIdChecked = false;
      }
    })
    .catch(() => {
      messageDiv.textContent = '중복확인 중 오류가 발생했습니다.';
      messageDiv.className = 'validation-message error';
      isIdChecked = false;
    })
    .finally(() => {
      btnEl.disabled = false;
      btnEl.textContent = original;
    });
}

function checkNicknameDuplicate(btnEl) {
  const nicknameInput = document.querySelector('input[name="nickname"]');
  const messageDiv = document.getElementById('nicknameMessage');
  const nickname = nicknameInput.value.trim();

  if (!nickname) {
    messageDiv.textContent = '닉네임을 입력해주세요.';
    messageDiv.className = 'validation-message error';
    nicknameInput.focus();
    return;
  }

  btnEl.disabled = true;
  const original = btnEl.textContent;
  btnEl.textContent = '확인중...';

  fetch('/checkNicknameDuplicate.do', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'nickname=' + encodeURIComponent(nickname)
  })
    .then(r => r.json())
    .then(data => {
      if (data.available) {
        messageDiv.textContent = data.message || '사용가능합니다.';
        messageDiv.className = 'validation-message success';
        isNicknameChecked = true;
      } else {
        messageDiv.textContent = data.message || '닉네임을 다시 입력해주세요.';
        messageDiv.className = 'validation-message error';
        isNicknameChecked = false;
      }
    })
    .catch(() => {
      messageDiv.textContent = '중복확인 중 오류가 발생했습니다.';
      messageDiv.className = 'validation-message error';
      isNicknameChecked = false;
    })
    .finally(() => {
      btnEl.disabled = false;
      btnEl.textContent = original;
    });
}

/* =============== 비밀번호 검증 =============== */
// 8~12자, 영문/숫자/특수기호 각각 1개 이상 포함
const PW_RULE = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[!@#$%^&*()_\-+=[\]{}|\\;:'",.<>/?`~]).{8,12}$/;

function checkPasswordMatch() {
  const password = document.querySelector('input[name="password"]').value;
  const passwordConfirm = document.querySelector('input[name="password_confirm"]').value;
  const messageDiv = document.getElementById('passwordMessage');

  if (isEmpty(passwordConfirm)) {
    messageDiv.textContent = '';
    messageDiv.className = 'validation-message';
    return;
  }

  if (password !== passwordConfirm) {
    messageDiv.textContent = '비밀번호가 일치하지 않습니다.';
    messageDiv.className = 'validation-message error';
  } else if (!PW_RULE.test(password)) {
    messageDiv.textContent = '8~12자 영문/숫자/특수기호를 모두 포함해야 합니다.';
    messageDiv.className = 'validation-message error';
  } else {
    messageDiv.textContent = '비밀번호가 일치합니다.';
    messageDiv.className = 'validation-message success';
  }
}

/* =============== 자동 하이픈 & 초기화 =============== */
function autoHyphenPhone(value) {
  const digits = value.replace(/\D/g, '').slice(0, 11); // 숫자만, 최대 11자리
  if (digits.length < 4) return digits;
  if (digits.length < 8) return digits.slice(0, 3) + '-' + digits.slice(3);
  return digits.slice(0, 3) + '-' + digits.slice(3, 7) + '-' + digits.slice(7);
}

document.addEventListener('DOMContentLoaded', function () {
  // 아이디/닉네임 입력 변경 시 중복확인 초기화
  const userIdInput = document.querySelector('input[name="user_id"]');
  userIdInput.addEventListener('input', function () {
    isIdChecked = false;
    const messageDiv = document.getElementById('idMessage');
    messageDiv.textContent = '';
    messageDiv.className = 'validation-message';
  });

  const nicknameInput = document.querySelector('input[name="nickname"]');
  nicknameInput.addEventListener('input', function () {
    isNicknameChecked = false;
    const messageDiv = document.getElementById('nicknameMessage');
    messageDiv.textContent = '';
    messageDiv.className = 'validation-message';
  });

  // 전화번호 자동 하이픈
  const phoneInput = document.querySelector('input[name="phone"]');
  if (phoneInput) {
    phoneInput.setAttribute('maxlength', '13'); // 000-0000-0000
    phoneInput.addEventListener('input', function (e) {
      const cur = e.target.selectionStart;
      const before = e.target.value;
      e.target.value = autoHyphenPhone(before);
      // 간단 버전: 커서는 끝으로 이동(정교한 커서 유지 필요시 추가 로직 작성)
      e.target.setSelectionRange(e.target.value.length, e.target.value.length);
    });
    phoneInput.addEventListener('paste', function (e) {
      e.preventDefault();
      const text = (e.clipboardData || window.clipboardData).getData('text');
      phoneInput.value = autoHyphenPhone(text);
    });
  }
});

/* =============== 제출 검증 =============== */
function validateForm() {
  // 1) 필수값 체크 (상세주소 제외) — 주소 id 주의: address
  const fields = [
    { el: document.querySelector('input[name="user_id"]'), label: '아이디' },
    { el: document.querySelector('input[name="password"]'), label: '비밀번호' },
    { el: document.querySelector('input[name="password_confirm"]'), label: '비밀번호 확인' },
    { el: document.querySelector('input[name="email"]'), label: '이메일' },
    { el: document.getElementById('domainInput'), label: '이메일 도메인' },
    { el: document.getElementById('postcode'), label: '우편번호' },
    { el: document.getElementById('address'), label: '도로명 주소' },
    { el: document.querySelector('input[name="phone"]'), label: '전화번호' }
  ];

  for (const { el, label } of fields) {
    if (!el) continue;
    if (isEmpty(el.value)) {
      alert(`${label}을(를) 입력해 주세요`);
      el.focus();
      return false;
    }
  }

  // 2) 아이디 중복확인
  if (!isIdChecked) {
    alert('아이디 중복확인을 해주세요');
    document.querySelector('input[name="user_id"]').focus();
    return false;
  }

  // 3) 비밀번호 규칙 + 일치 여부
  const pw = document.querySelector('input[name="password"]').value;
  const pw2 = document.querySelector('input[name="password_confirm"]').value;

  if (!PW_RULE.test(pw)) {
    alert('비밀번호는 8~12자이며, 영문/숫자/특수기호를 모두 포함해야 합니다.');
    document.querySelector('input[name="password"]').focus();
    return false;
  }
  if (pw !== pw2) {
    alert('비밀번호가 일치하지 않습니다.');
    document.querySelector('input[name="password_confirm"]').focus();
    return false;
  }

  // 4) 전화번호 형식 검사
  const phoneInput = document.querySelector('input[name="phone"]');
  const phone = phoneInput.value.trim();
  const phonePattern = /^\d{3}-\d{4}-\d{4}$/;
  if (!phonePattern.test(phone)) {
    alert('전화번호는 000-0000-0000 형식으로 입력해 주세요.');
    phoneInput.focus();
    return false;
  }

  // 5) 닉네임이 입력된 경우 중복확인 여부
  const nicknameInput = document.querySelector('input[name="nickname"]');
  if (!isEmpty(nicknameInput.value) && !isNicknameChecked) {
    alert('닉네임 중복확인을 해주세요');
    nicknameInput.focus();
    return false;
  }

  return true;
}

/* =============== 전화번호 onblur 시 안내(시각 피드백) =============== */
function validatePhoneFormat() {
  const phoneInput = document.querySelector('input[name="phone"]');
  const phoneMessage = document.getElementById('phoneMessage');
  const phone = phoneInput.value.trim();

  if (isEmpty(phone)) {
    phoneMessage.textContent = '전화번호를 입력해 주세요.';
    phoneMessage.className = 'validation-message error';
    return;
  }

  const phonePattern = /^\d{3}-\d{4}-\d{4}$/;
  if (phonePattern.test(phone)) {
    phoneMessage.textContent = '';
    phoneMessage.className = 'validation-message';
  } else {
    phoneMessage.textContent = '000-0000-0000 형식에 맞게 입력해주세요.';
    phoneMessage.className = 'validation-message error';
  }
}

/* =============== Daum 주소 API =============== */
function execDaumPostcode() {
  new daum.Postcode({
    oncomplete: function (data) {
      // 도로명 선택 시 data.roadAddress, 지번 선택 시 data.jibunAddress
      var addr = (data.userSelectedType === 'R') ? data.roadAddress : data.jibunAddress;
      document.getElementById('postcode').value = data.zonecode;
      document.getElementById('address').value  = addr;          // id: address 로 맞춤
      document.getElementById('detailaddress').focus();          // id: detailaddress 로 맞춤
    }
  }).open();
}
