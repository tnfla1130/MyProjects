package org.spring.projectjs.JPA.member;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/member")
public class JPAMemberController {

    JPAMemberService memberService;

    //생성자
    public JPAMemberController(JPAMemberService memberService) {
        this.memberService = memberService;
    }

    //전체 회원 조회
    @GetMapping
    public List<JPAMember> getAllMembers() {
        return memberService.getAllMembers();
    }

    //회원 생성
    @PostMapping
    public JPAMember createMember(@RequestBody JPAMember member) {
        return memberService.createMember(member);
    }

    //개별 회원 조회
    @GetMapping("/searchMember/{memberIdx}")
    public JPAMember getMemberById(@PathVariable String nickname) {
        return memberService.getMemberByNickname(nickname);
    }

    //회원 수정
    @PutMapping("/editMember{memberidx}")
    public JPAMember updateMember(@PathVariable Long memberIdx, @RequestBody JPAMember member) {
        return memberService.updatedMember(memberIdx, member);
    }

    //회원 삭제
    @DeleteMapping("/deleteMember/{memberIdx}")
    public void deleteMember(@PathVariable Long memberIdx) {
        memberService.deleteMember(memberIdx);
    }

}
