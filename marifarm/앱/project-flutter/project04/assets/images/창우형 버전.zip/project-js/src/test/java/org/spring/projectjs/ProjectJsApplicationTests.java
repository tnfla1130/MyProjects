package org.spring.projectjs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectJsApplicationTests {

    @Test
    void contextLoads() {
    }

}
