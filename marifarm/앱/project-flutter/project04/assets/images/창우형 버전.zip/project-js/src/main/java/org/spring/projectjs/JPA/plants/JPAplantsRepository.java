package org.spring.projectjs.JPA.plants;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JPAplantsRepository extends JpaRepository<JPAplants, Long> {
    // 문의 기반 추천
    List<JPAplants> findByMinTempGreaterThanEqualAndMaxTempLessThanEqualAndDifficultyLessThanEqualAndMaxGrowDaysLessThanEqual(
            int minTemp, int maxTemp, int difficulty, int growDays);


    // 🔹 키우기 쉬운 식물 자동 추천 (난이도 <= 2)
    List<JPAplants> findByDifficultyLessThanEqual(Integer difficulty);

    //검색기능
    List<JPAplants> findByNameContainingIgnoreCase(String name);
}
